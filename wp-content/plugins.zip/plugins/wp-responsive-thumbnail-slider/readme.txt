=== wordpress responsive thumbnail slider ===
Contributors:nik00726
Donate link: http://www.i13websolution.com/donate-wordpress_image_thumbnail.php
Tags:wordpress responsive slideshow,responsive thumbnail gallery,wordpress responsive slider with thumbnails,wordpress gallery responsive,wordpress fluid slider,wordpress fluid thumbnails slider,wordpress responsive image slider
Requires at least:3.5
Tested up to:4.5
Version:1.4
Stable tag:trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is beautiful responsive image slider for wordPress blogs and sites.Admin can manages any number of images into the responsive slider.

== Description ==



This is beautiful responsive image slider for wordPress blogs and sites.Admin can manages any number of images into the responsive slider.
Admin can add,edit and delete slider images.Before add slider to wordPress blog admin can preview a slider.Admin can set height,width of slider images.Admin can also set speed,Number Of visible images into slider,Circular slider.Admin can also set if want to slide images with up and down arrow or by automatic slider.


**Find WordPress Responsive Image Slider Pro Plugin(Unlimited Slider+Mass Images Uploads+Much More) at [WordPress Responsive Thumbnail Slider](http://www.i13websolution.com/wordpress-responsive-thumbnail-slider-pro.html)**

**[Live Demo Responsive Thumbnail Slider Pro](http://blog.i13websolution.com/live-preview-responsive-thumbnail-slider-pro/)**


**Please rate this plugin if you find it useful**


**=Features=**

1. Add any number of images to responsive slider.

2. Edit images and image name.

3. Image name is used as alt tag for seo.

4. Preview your slider before use it.

5. Slider installation into theme is simple just add shortcode 
to theme or pages/posts.

6. changes to images height,width

7. Changes to slider speed is easy.

8. Admin can set slider as slide with arrow left and right arrow.

9. Admin can set slider as circular slider.

10. Responsive admin layout.

**=Pro Version Features=**

1. Unlimited Slider(Multiple sliders).

2. Mass Images Upload.

3. Upload image using media uploader(wp >3.5) Or simple uploader.

4. Add wordpress featured image in responsive slider directly from post/page add/edit.

5. Slider Easing Effects(select your desired slider easing effect from 16 easing effect).

6. No advertisements.

7. If image description set it will added to image title tag for seo.

8. Admin can display slider according image order.

9. Open image link in new tab or same tab.

10. Display slider with paging.

11. Display slider image with caption.

12. Responsive admin layout.


[Get Support](http://www.i13websolution.com/contacts)


== Installation ==


This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. upload wp-responsive-image-slider folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use wordpress image slider.

### Usage ###

1.Use of wordpress responsive slider is easy after activating plugin go to Responsive Imaages Slider.

2.You can manage images by Manage images menu.

3.You can set settings for this plugin using slider settings menu.

4.You can add this slider to your wordpress page/post by adding this shortcode to [print_responsive_thumbnail_slider] 

OR you can add this to your theme by adding this code echo do_shortcode('[print_responsive_thumbnail_slider]'); to your theme


== Screenshots ==


1. Slider Setting
2. Manage Images 
3. Preview Slider
4. Front End slider
5. Pro version manage sliders
6. Pro version add/edit image
7. Pro version add/edit slider.
8. Pro version admin slider preview
9. Pro version featured image add/edit directly from post or page.

== License ==


This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.


== Changelog ==

= 1.0 =

* Stable 1.0 first release


== Upgrade notice ==


* Stable 1.0 first release


== Frequently asked questions ==

1.How to use ?

For More info use readme installation and usage notes.
