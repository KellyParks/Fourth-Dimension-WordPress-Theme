<footer role="contentinfo" class="remodal-bg">
	<div class="container">
		<div class="far-left-container">
			<?php dynamic_sidebar('footer-logo-and-contact-info'); ?>
		</div>
		<?php dynamic_sidebar('footer-form'); ?>
		<?php dynamic_sidebar('footer-map'); ?>
	</div>
	<!-- make the copyright year dynamic by grabbing the current year from the server -->
	<p>Copyright <?php echo date("Y"); ?></p>
</footer>

<!-- this makes the horizontal admin bar appear at the top of the site while 
in admin mode (for some weird reason, it's turned to display: none by default). 
Without this little bit of code, you'd most likely see a white 
bar at the top while logged in. -->
<?php wp_footer(); ?>
<script>
//$(document).ready(function(){
	//$(".heroImg, .whatWeDo, .testimonials, footer").addClass("light-overlay");

	//$('.heroImg, .whatWeDo, .testimonials, footer').children().prop('disabled',true);
        //$('.heroImg, .whatWeDo, .testimonials, footer').bind('click', false);

	//$('body > div').addClass('hide');

      //$('article').on('click', function(){
        var id = $(this).attr('id');

        //$("#popout-" + id).dialog();
        //$('body > div').addClass('hide');
        // if(id === undefined){
        // 	alert('nope');
        // }
        // alert('yep');
        
        //$("#popout-" + id).removeClass("hide");

        // if(id === undefined){
        // 	alert('nope');
        // }
        // alert('yep');
      //});
  //  });
</script>

</body>
</html>
