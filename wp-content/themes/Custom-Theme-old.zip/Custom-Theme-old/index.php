<?php get_header(); ?>
<section class="whatWeDo remodal-bg">
	<div class="container">
		<h2>What We Do</h2>
		<p>Fourth Dimension Construction is a Fraser Valley based renovation and new construction company that has client oriented, experienced employees.</p>
		<p>With no job too big and no job too small, Fourth Dimension Construction will be able to provide complete construction services.</p>
	</div>
	<div class="dark-overlay">
		<div class="container">
		<div class="servicesContainer">
			<?php
			// Set up the objects
			$my_wp_query = new WP_Query();
			$all_wp_pages = $my_wp_query->query(array('post_type' => 'page'));

			// Get the services page as an object
			$services = get_page_by_title('Services');

			// Filter through all the service pages and find the children only
			$servicesChildPages = get_page_children($services->ID, $all_wp_pages);

			foreach($servicesChildPages as $page){
					echo '<article>
							<h2><a href="#'. $page->ID . '">' . $page->post_title . '</a></h2>
							<p>' . $page->post_excerpt . '</p>' . 
							get_the_post_thumbnail($page->ID, array(356,192)) . 
						'</article></a>';
				}
			?>
		</div>
	</div>
	</div>
</section>
<?php 
	foreach($servicesChildPages as $page){
		echo '<div class="remodal" data-remodal-id="' . $page->ID . '" role="dialog" aria-labelledby="modal1Title" aria-describedby="modal1Desc">
		<button data-remodal-action="close" class="remodal-close" aria-label="Close"></button>
			<div>
				<h2 id="' . $page->ID . '">' . $page->post_title . '</h2>
				<p>' . wpautop($page->post_content) . '</p>
			</div>';

?>
<?php 
if ($page->post_title == 'Residential'){
	echo do_shortcode('[print_responsive_thumbnail_slider id="2"]');
}
?>
		<?php dynamic_sidebar('footer-logo-and-contact-info'); ?>
		<?php dynamic_sidebar('footer-form'); ?>
<?php
	echo '</div>'; }
?>
<section class="testimonials remodal-bg">
	<div class="container">
		<?php dynamic_sidebar('testimonials'); ?>
	</div>
</section>
<?php get_footer(); ?>