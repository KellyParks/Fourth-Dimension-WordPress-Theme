<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Site Title</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body>
<header role="banner">
	<div class="topBarBackground">
		<div class="container">
			<div class="logo-container">
	  			<?php the_custom_logo(); ?>
	  		<!-- <div class="menu-and-hours"> -->
	      		<?php dynamic_sidebar('Header-Hours-of-operation-and-contact'); ?>
	      		</div>
	      		<?php wp_nav_menu(array('theme_location' => 'header-menu')); ?>
	      	</div>
	    </div>
	</div>
	<div class="heroImg remodal-bg">
		<div class="container">
		<p>Welcome to Fourth Dimension Construction</p>
		<img src="http://localhost:8888/Fourth-Dimension/wordpress/wp-content/themes/Custom-Theme/img/lines-top2.svg" alt="" class="lines">
		<h1>Concept <span>to Quality</span> Completion.</h1>
		<img src="http://localhost:8888/Fourth-Dimension/wordpress/wp-content/themes/Custom-Theme/img/lines-bottom2.svg" alt="" class="lines">
		<p>Contact us today to tell us about your next project!</p>
	</div>
	</div>
</header>